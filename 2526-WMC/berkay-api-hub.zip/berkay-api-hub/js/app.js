document.addEventListener('DOMContentLoaded', () => {

  document.getElementById('year').textContent = new Date().getFullYear();

  const main = document.getElementById('main-content');
  const navBtns = document.querySelectorAll('.nav-btn');

  /* ---- navigation ---- */

  function navigate(page) {
    navBtns.forEach((btn) => {
      if (btn.dataset.page === page) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    while (main.firstChild) {
      main.removeChild(main.firstChild);
    }

    switch (page) {
      case 'home':
        renderHome();
        break;
      case 'explore':
        renderExplore();
        break;
      case 'collection':
        renderCollection();
        break;
    }
  }

  navBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      navigate(btn.dataset.page);
    });
  });

  /* ---- Home ---- */

  function renderHome() {
    const page = createPage();

    const hero = createCard();
    hero.classList.add('hero');
    hero.appendChild(createElement('h2', 'Willkommen beim API Discovery Hub'));
    hero.appendChild(
      createElement(
        'p',
        'Entdecke spannende Daten aus öffentlichen APIs – erkunde, sammle und vergleiche!'
      )
    );
    page.appendChild(hero);

    const factCard = createCard();
    factCard.appendChild(createElement('h2', 'Fakt des Tages'));
    const factBox = document.createElement('div');
    factBox.className = 'fact-box';
    const factP = createElement('p', 'Lade Fakt …');
    factBox.appendChild(factP);
    factCard.appendChild(factBox);
    page.appendChild(factCard);

    const dogCard = createCard();
    dogCard.appendChild(createElement('h2', 'Zufälliger Hund'));
    const dogDiv = document.createElement('div');
    dogDiv.id = 'dog-container';
    dogDiv.textContent = 'Lade Bild …';
    dogCard.appendChild(dogDiv);
    page.appendChild(dogCard);

    main.appendChild(page);

    API.fetchCatFact()
      .then((data) => {
        const newP = createElement('p', data.fact);
        factBox.replaceChild(newP, factBox.firstChild);
      })
      .catch(() => {
        factBox.firstChild.textContent = 'Fakt konnte nicht geladen werden.';
      });

    API.fetchDogImage()
      .then((data) => {
        const img = document.createElement('img');
        img.src = data.message;
        img.alt = 'Zufälliger Hund';
        img.className = 'dog-image';
        dogDiv.textContent = '';
        dogDiv.appendChild(img);
      })
      .catch(() => {
        dogDiv.textContent = 'Bild konnte nicht geladen werden.';
      });
  }

  /* ---- Explore ---- */

  let currentResult = null;

  function renderExplore() {
    const page = createPage();

    const headerCard = createCard();
    headerCard.appendChild(
      createElement('h2', 'Entdecken – wähle eine Kategorie')
    );
    headerCard.appendChild(
      createElement(
        'p',
        'Klicke auf eine Kategorie, um Daten von einer öffentlichen API abzurufen.'
      )
    );
    page.appendChild(headerCard);

    const catGrid = document.createElement('div');
    catGrid.className = 'categories';

    const cats = [
      { id: 'cat', label: 'Katzen-Fakt', emoji: '🐱' },
      { id: 'dog', label: 'Hunde-Bild', emoji: '🐕' },
      { id: 'joke', label: 'Witz', emoji: '😂' },
      { id: 'user', label: 'Zufallsnutzer', emoji: '👤' },
    ];

    cats.forEach((c) => {
      const btn = document.createElement('button');
      btn.className = 'cat-btn';
      btn.textContent = `${c.emoji} ${c.label}`;
      btn.dataset.cat = c.id;
      catGrid.appendChild(btn);
    });

    page.appendChild(catGrid);

    const resultCard = createCard();
    resultCard.id = 'result-card';
    const resultTitle = createElement('h3', 'Ergebnis');
    resultCard.appendChild(resultTitle);

    const resultArea = document.createElement('div');
    resultArea.className = 'result-area';
    resultArea.id = 'result-area';
    resultArea.appendChild(
      createElement('p', 'Wähle eine Kategorie oben aus.')
    );
    resultCard.appendChild(resultArea);

    const addBtn = document.createElement('button');
    addBtn.className = 'btn';
    addBtn.id = 'add-btn';
    addBtn.textContent = 'Zur Sammlung hinzufügen';
    addBtn.style.display = 'none';
    resultCard.appendChild(addBtn);

    page.appendChild(resultCard);

    main.appendChild(page);

    /* ---- Kategorie-Klick ---- */
    catGrid.addEventListener('click', (e) => {
      const btn = e.target.closest('.cat-btn');
      if (!btn) return;

      document.querySelectorAll('.cat-btn').forEach((b) => {
        b.disabled = true;
      });

      const resultArea = document.getElementById('result-area');

      while (resultArea.firstChild) {
        resultArea.removeChild(resultArea.firstChild);
      }

      const loading = createElement('p', 'Lade Daten …');
      loading.className = 'loading';
      resultArea.appendChild(loading);

      document.getElementById('add-btn').style.display = 'none';
      currentResult = null;

      const cat = btn.dataset.cat;
      let promise;

      switch (cat) {
        case 'cat':
          promise = API.fetchCatFact();
          break;
        case 'dog':
          promise = API.fetchDogImage();
          break;
        case 'joke':
          promise = API.fetchJoke();
          break;
        case 'user':
          promise = API.fetchRandomUser();
          break;
      }

      promise
        .then((data) => {
          while (resultArea.firstChild) {
            resultArea.removeChild(resultArea.firstChild);
          }

          const content = document.createElement('div');
          content.className = 'result-content';

          if (cat === 'cat') {
            content.appendChild(createElement('p', data.fact));
            currentResult = { type: 'cat', data: { fact: data.fact } };
          } else if (cat === 'dog') {
            const img = document.createElement('img');
            img.src = data.message;
            img.alt = 'Hund';
            content.appendChild(img);
            currentResult = { type: 'dog', data: { url: data.message } };
          } else if (cat === 'joke') {
            content.appendChild(createElement('p', data.setup));
            const punchP = createElement('p', data.punchline);
            punchP.style.fontWeight = 'bold';
            content.appendChild(punchP);
            currentResult = {
              type: 'joke',
              data: { setup: data.setup, punchline: data.punchline },
            };
          } else if (cat === 'user') {
            const user = data.results[0];
            content.appendChild(
              createElement(
                'p',
                `Name: ${user.name.first} ${user.name.last}`
              )
            );
            content.appendChild(createElement('p', `Email: ${user.email}`));
            const img = document.createElement('img');
            img.src = user.picture.medium;
            img.alt = 'Profilbild';
            content.appendChild(img);
            currentResult = {
              type: 'user',
              data: {
                name: `${user.name.first} ${user.name.last}`,
                email: user.email,
                picture: user.picture.medium,
              },
            };
          }

          resultArea.appendChild(content);

          const addBtn = document.getElementById('add-btn');
          addBtn.style.display = 'inline-block';
        })
        .catch((err) => {
          while (resultArea.firstChild) {
            resultArea.removeChild(resultArea.firstChild);
          }
          const errDiv = document.createElement('div');
          errDiv.className = 'error';
          errDiv.textContent = 'Fehler beim Laden: ' + err.message;
          resultArea.appendChild(errDiv);
        })
        .finally(() => {
          document.querySelectorAll('.cat-btn').forEach((b) => {
            b.disabled = false;
          });
        });
    });

    /* ---- In Sammlung speichern ---- */
    document.getElementById('add-btn').addEventListener('click', () => {
      if (currentResult) {
        Collection.add({ ...currentResult, date: Date.now() });
        const addBtn = document.getElementById('add-btn');
        addBtn.textContent = 'Gespeichert!';
        addBtn.disabled = true;
        setTimeout(() => {
          addBtn.textContent = 'Zur Sammlung hinzufügen';
          addBtn.disabled = false;
        }, 1500);
      }
    });
  }

  /* ---- Collection ---- */

  function renderCollection() {
    const page = createPage();

    const headerCard = createCard();
    headerCard.appendChild(createElement('h2', 'Meine Sammlung'));
    headerCard.appendChild(
      createElement(
        'p',
        'Hier siehst du alle gespeicherten Einträge. Du kannst sie sortieren oder löschen.'
      )
    );
    page.appendChild(headerCard);

    const controls = document.createElement('div');
    controls.className = 'collection-controls';

    const sortTypeBtn = document.createElement('button');
    sortTypeBtn.className = 'btn btn-secondary';
    sortTypeBtn.textContent = 'Nach Typ sortieren';
    controls.appendChild(sortTypeBtn);

    const sortDateBtn = document.createElement('button');
    sortDateBtn.className = 'btn btn-secondary';
    sortDateBtn.textContent = 'Nach Datum sortieren';
    controls.appendChild(sortDateBtn);

    const countP = document.createElement('p');
    countP.id = 'collection-count';
    countP.style.marginLeft = 'auto';
    countP.style.color = 'var(--text-light)';
    controls.appendChild(countP);

    page.appendChild(controls);

    const listDiv = document.createElement('div');
    listDiv.id = 'collection-list';
    page.appendChild(listDiv);

    main.appendChild(page);

    function renderList() {
      while (listDiv.firstChild) {
        listDiv.removeChild(listDiv.firstChild);
      }

      const items = Collection.getAll();

      countP.textContent = `${items.length} Eintrag${items.length !== 1 ? 'e' : ''}`;

      if (items.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'collection-empty';
        empty.appendChild(createElement('p', 'Deine Sammlung ist noch leer.'));
        const hint = createElement(
          'p',
          'Gehe zu "Entdecken" und füge Einträge hinzu!'
        );
        hint.style.fontSize = '0.9rem';
        empty.appendChild(hint);
        listDiv.appendChild(empty);
        return;
      }

      items.forEach((item, index) => {
        const div = document.createElement('div');
        div.className = 'collection-item';

        const info = document.createElement('div');
        info.className = 'item-info';

        const typeSpan = document.createElement('span');
        typeSpan.className = 'item-type';
        const typeLabels = {
          cat: 'Katzen-Fakt',
          dog: 'Hunde-Bild',
          joke: 'Witz',
          user: 'Zufallsnutzer',
        };
        typeSpan.textContent = typeLabels[item.type] || item.type;
        info.appendChild(typeSpan);

        const textP = document.createElement('p');
        if (item.type === 'cat') {
          textP.textContent = item.data.fact;
        } else if (item.type === 'dog') {
          textP.textContent = 'Hunde-Bild (klicke zum Öffnen)';
          const link = document.createElement('a');
          link.href = item.data.url;
          link.target = '_blank';
          link.textContent = ' Bild ansehen';
          textP.appendChild(link);
        } else if (item.type === 'joke') {
          textP.textContent = `${item.data.setup} → ${item.data.punchline}`;
        } else if (item.type === 'user') {
          textP.textContent = `${item.data.name} (${item.data.email})`;
        }
        info.appendChild(textP);

        const dateP = document.createElement('p');
        dateP.className = 'item-date';
        dateP.textContent = new Date(item.date).toLocaleDateString('de-DE', {
          hour: '2-digit',
          minute: '2-digit',
        });
        info.appendChild(dateP);

        div.appendChild(info);

        const delBtn = document.createElement('button');
        delBtn.className = 'btn btn-danger';
        delBtn.textContent = 'Löschen';
        delBtn.addEventListener('click', () => {
          Collection.remove(index);
          renderList();
        });
        div.appendChild(delBtn);

        listDiv.appendChild(div);
      });
    }

    sortTypeBtn.addEventListener('click', () => {
      Collection.sortBy('type');
      renderList();
    });

    sortDateBtn.addEventListener('click', () => {
      Collection.sortBy('date');
      renderList();
    });

    renderList();
  }

  /* ---- Hilfsfunktionen ---- */

  function createPage() {
    const page = document.createElement('div');
    page.className = 'page';
    return page;
  }

  function createCard() {
    const card = document.createElement('div');
    card.className = 'card';
    return card;
  }

  function createElement(tag, text) {
    const el = document.createElement(tag);
    el.textContent = text;
    return el;
  }

  /* ---- Start ---- */
  navigate('home');
});
