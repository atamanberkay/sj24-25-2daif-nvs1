const API = {
  async fetchCatFact() {
    const res = await fetch('https://catfact.ninja/fact');
    if (!res.ok) throw new Error('Cat-Fact-Fehler');
    return res.json();
  },

  async fetchDogImage() {
    const res = await fetch('https://dog.ceo/api/breeds/image/random');
    if (!res.ok) throw new Error('Dog-Bild-Fehler');
    return res.json();
  },

  async fetchJoke() {
    const res = await fetch(
      'https://official-joke-api.appspot.com/random_joke'
    );
    if (!res.ok) throw new Error('Witz-Fehler');
    return res.json();
  },

  async fetchRandomUser() {
    const res = await fetch('https://randomuser.me/api/');
    if (!res.ok) throw new Error('User-Fehler');
    return res.json();
  },
};
