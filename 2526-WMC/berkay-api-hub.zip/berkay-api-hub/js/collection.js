const Collection = {
  items: [],

  add(item) {
    this.items.push(item);
  },

  remove(index) {
    if (index >= 0 && index < this.items.length) {
      this.items.splice(index, 1);
    }
  },

  sortBy(key) {
    if (key === 'type') {
      this.items.sort((a, b) => a.type.localeCompare(b.type));
    } else if (key === 'date') {
      this.items.sort((a, b) => a.date - b.date);
    }
  },

  getAll() {
    return [...this.items];
  },

  getLength() {
    return this.items.length;
  },
};
