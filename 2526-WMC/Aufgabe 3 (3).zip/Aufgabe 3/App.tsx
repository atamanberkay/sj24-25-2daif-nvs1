import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';

import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-secondary-50 font-sans text-secondary-900 antialiased selection:bg-primary-200 selection:text-primary-900">
      <Header />
      <main>
        <Hero />
      </main>
      <Footer />
    </div>
  );
}

export default App;