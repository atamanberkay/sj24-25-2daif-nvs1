import React, { useState, useEffect } from 'react';
import { Menu, X, Instagram } from 'lucide-react';

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Updated 'Startseite' to point to #hero explicitly
  const navLinks = [
    { name: 'Startseite', href: '#hero' },
    { name: 'Über uns', href: '#ueber-uns' },
    { name: 'Leistungen', href: '#leistungen' },
    { name: 'Ablauf', href: '#ablauf' },
    { name: 'Kontakt', href: '#kontakt' },
  ];

  // Smooth scroll handler
  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);

    // Extract ID (remove #)
    const targetId = href.replace(/.*\#/, "");
    const elem = document.getElementById(targetId);

    if (elem) {
      const headerOffset = 90; // Height of fixed header + buffer
      const elementPosition = elem.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <a 
          href="#hero" 
          onClick={(e) => handleScroll(e, '#hero')}
          className="text-xl md:text-2xl font-heading font-bold text-secondary-900"
        >
          Bioresonanz <span className="text-primary-600">Toker</span>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6 lg:gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              onClick={(e) => handleScroll(e, link.href)}
              className="text-secondary-700 font-medium hover:text-primary-600 transition-colors text-sm uppercase tracking-wide cursor-pointer"
            >
              {link.name}
            </a>
          ))}
          
          <div className="h-4 w-px bg-secondary-300 mx-2"></div>

          <a 
            href="https://www.instagram.com/bioresonanz.wien/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-secondary-700 hover:text-primary-600 transition-colors"
            aria-label="Instagram"
          >
            <Instagram size={20} />
          </a>

          <a 
            href="#kontakt"
            onClick={(e) => handleScroll(e, '#kontakt')}
            className="px-5 py-2 bg-primary-600 text-white rounded-lg font-semibold hover:bg-primary-700 transition-colors shadow-lg shadow-primary-500/20 cursor-pointer"
          >
            Termin
          </a>
        </nav>

        {/* Mobile Toggle */}
        <div className="flex items-center gap-4 md:hidden">
          <a 
            href="https://www.instagram.com/bioresonanz.wien/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-secondary-900 hover:text-primary-600 transition-colors"
          >
            <Instagram size={24} />
          </a>
          <button 
            className="text-secondary-900"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="absolute top-full left-0 right-0 bg-white border-t border-secondary-100 p-6 md:hidden shadow-xl flex flex-col gap-4 animate-fade-in-down">
           {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              onClick={(e) => handleScroll(e, link.href)}
              className="text-lg font-heading font-medium text-secondary-800 py-2 border-b border-secondary-50 last:border-0 cursor-pointer"
            >
              {link.name}
            </a>
          ))}
          <a 
            href="#kontakt"
            onClick={(e) => handleScroll(e, '#kontakt')}
            className="mt-2 w-full text-center px-5 py-3 bg-primary-600 text-white rounded-lg font-bold cursor-pointer"
          >
            Jetzt Termin vereinbaren
          </a>
        </div>
      )}
    </header>
  );
};