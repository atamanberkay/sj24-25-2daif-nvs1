import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-secondary-900 text-secondary-400 py-12">
      <div className="container mx-auto px-4 text-center md:text-left">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8 border-b border-secondary-800 pb-8">
            <div>
                <h4 className="text-white font-heading font-bold text-lg mb-4">Bioresonanz Hasan Toker</h4>
                <p className="text-sm">Ganzheitliche Gesundheit für Körper und Geist in Wien 1150.</p>
            </div>
            <div>
                <h4 className="text-white font-heading font-bold text-lg mb-4">Rechtliches</h4>
                <ul className="space-y-2 text-sm">
                    <li><a href="#" className="hover:text-white transition-colors">Impressum</a></li>
                    <li><a href="#" className="hover:text-white transition-colors">Datenschutz</a></li>
                </ul>
            </div>
             <div>
                <h4 className="text-white font-heading font-bold text-lg mb-4">Hinweis</h4>
                <p className="text-xs leading-relaxed">
                    Die Bioresonanzmethode gehört ebenso wie z.B. die Homöopathie und andere Verfahren der besonderen Therapierichtungen in den Bereich der Regulativen Medizin.
                </p>
            </div>
        </div>
        <div className="flex flex-col md:flex-row justify-between items-center text-xs">
            <p>&copy; {new Date().getFullYear()} Hasan Toker, B.A. Alle Rechte vorbehalten.</p>
            <p className="mt-2 md:mt-0">Designed with Care.</p>
        </div>
      </div>
    </footer>
  );
};
