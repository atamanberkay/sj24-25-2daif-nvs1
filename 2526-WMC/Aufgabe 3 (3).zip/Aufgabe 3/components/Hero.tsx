import React from 'react';
import Hasan from '../image/hasan.jpg';
import Heroo from '../image/Hero.png';
import { ArrowRight, CheckCircle2, Leaf, Clock, MapPin, Phone, Mail, Calendar, ShieldCheck, Heart, Zap, Brain } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <>
      {/* 1. HERO SECTION */}
      <section id="hero" className="relative w-full min-h-[90vh] flex items-center justify-center overflow-hidden pt-16">
        {/* Background with overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src={Heroo}
            alt="Bioresonanz Balance" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-secondary-50/95 via-secondary-50/80 to-secondary-50/40 md:to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-secondary-50 via-transparent to-transparent"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10 flex flex-col md:flex-row items-center">
          <div className="w-full md:w-2/3 lg:w-1/2 space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-100 text-primary-800 text-sm font-semibold tracking-wide">
              <Leaf size={16} />
              <span>Neu in 1150 Wien</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-heading font-bold text-secondary-900 leading-[1.1]">
              Bioresonanz in Wien – <br />
              <span className="text-primary-600">sanft, modern & individuell.</span>
            </h1>
            
            <p className="text-lg md:text-xl text-secondary-800 leading-relaxed max-w-lg border-l-4 border-primary-400 pl-6">
              Unterstützung bei Allergien, Stress, Schlafproblemen & mehr. 
            </p>
            
            <div className="pt-4">
              <a 
                href="#kontakt" 
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-primary-600 text-white rounded-xl font-semibold hover:bg-primary-700 transition-all shadow-lg hover:shadow-primary-500/30 transform hover:-translate-y-1"
              >
                Termin vereinbaren
                <ArrowRight size={20} />
              </a>
            </div>
          </div>
          
          <div className="hidden md:block w-1/3 lg:w-1/2 h-[600px]"></div>
        </div>
      </section>

      {/* 2. ÜBER UNS SECTION */}
      <section id="ueber-uns" className="py-20 bg-secondary-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
            {/* Image Column */}
            <div className="w-full lg:w-1/2 relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl aspect-[4/5] lg:aspect-square">
                <img 
                  src={Hasan}
                  alt="Hasan Toker" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-secondary-900/90 to-transparent p-8">
                  <p className="text-white font-heading text-2xl font-bold">Hasan Toker, B.A.</p>
                  <p className="text-primary-200">Gesundheitsberater & Inhaber</p>
                </div>
              </div>
              {/* Decorative background element */}
              <div className="absolute -z-10 top-10 -left-10 w-full h-full border-2 border-primary-200 rounded-2xl hidden lg:block"></div>
            </div>

            {/* Text Column */}
            <div className="w-full lg:w-1/2 space-y-8">
              <div>
                <h2 className="text-3xl md:text-4xl font-heading font-bold text-secondary-900 mb-4">
                  Über uns – <span className="text-primary-600">professionell & persönlich</span>
                </h2>
                <div className="h-1.5 w-24 bg-primary-500 rounded-full"></div>
              </div>

              <div className="prose prose-lg text-secondary-700">
                <p className="font-medium text-xl text-secondary-900">
                  Willkommen bei Bioresonanz Hasan Toker!
                </p>
                <p>
                  Ich bin Hasan Toker, B.A., Gesundheitsberater. Mein Fokus liegt darauf, Menschen mit modernen Frequenzverfahren und einem ganzheitlichen Blick auf Körper und Emotionen zu unterstützen.
                </p>
                
                <h3 className="text-lg font-bold text-secondary-900 mt-6 mb-3">Was mir wichtig ist:</h3>
                <ul className="space-y-3">
                  {[
                    "Individuelle Analyse statt Standard-Behandlungen",
                    "Moderne Bioresonanz-Technologie",
                    "Natürliche, schonende Methoden",
                    "Ein ruhiges, vertrauensvolles Umfeld"
                  ].map((item, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <div className="mt-1 bg-primary-100 p-1 rounded-full text-primary-600">
                        <CheckCircle2 size={16} />
                      </div>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>

                <p className="mt-6">
                  In meiner Praxis begleite ich Klient:innen dabei, ihre körperlichen und emotionalen Belastungen besser zu verstehen und langfristig zu verbessern.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. LEISTUNGEN SECTION */}
      <section id="leistungen" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-secondary-900 mb-4">
              Meine Leistungen
            </h2>
            <p className="text-secondary-600">
              Klar strukturiert und individuell auf Ihre Bedürfnisse abgestimmt.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Service 1 */}
            <div className="p-8 rounded-2xl bg-secondary-50 border border-secondary-100 hover:shadow-xl transition-shadow group">
              <div className="w-12 h-12 bg-teal-100 text-teal-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <ShieldCheck size={28} />
              </div>
              <h3 className="text-xl font-heading font-bold text-secondary-900 mb-4">Allergien & Unverträglichkeiten</h3>
              <p className="text-secondary-700 mb-4 text-sm">Beispiele: Pollen, Lebensmittel, Tierhaare</p>
              <div className="bg-white p-4 rounded-lg border-l-4 border-teal-500">
                <p className="text-sm font-medium text-secondary-900">
                  <span className="text-teal-600 font-bold">Ziel:</span> Belastungen erkennen, Reizreaktionen harmonisieren, Beschwerden reduzieren.
                </p>
              </div>
            </div>

            {/* Service 2 */}
            <div className="p-8 rounded-2xl bg-secondary-50 border border-secondary-100 hover:shadow-xl transition-shadow group">
              <div className="w-12 h-12 bg-violet-100 text-violet-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Brain size={28} />
              </div>
              <h3 className="text-xl font-heading font-bold text-secondary-900 mb-4">Stress, Schlaf & Emotionen</h3>
              <ul className="text-secondary-700 mb-4 space-y-1 text-sm list-disc pl-4">
                <li>Stressbeschwerden</li>
                <li>Panikattacken & Angstzustände</li>
                <li>Schlafprobleme</li>
              </ul>
              <div className="bg-white p-4 rounded-lg border-l-4 border-violet-500">
                <p className="text-sm font-medium text-secondary-900">
                  <span className="text-violet-600 font-bold">Ziel:</span> Nervensystem beruhigen, innere Balance stärken.
                </p>
              </div>
            </div>

            {/* Service 3 */}
            <div className="p-8 rounded-2xl bg-secondary-50 border border-secondary-100 hover:shadow-xl transition-shadow group">
              <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Zap size={28} />
              </div>
              <h3 className="text-xl font-heading font-bold text-secondary-900 mb-4">Stoffwechsel & Körper</h3>
              <ul className="text-secondary-700 mb-4 space-y-1 text-sm list-disc pl-4">
                <li>Abnehmen mit Bioresonanz</li>
                <li>Verdauungsbeschwerden</li>
                <li>Immunsystem stärken</li>
              </ul>
              <div className="bg-white p-4 rounded-lg border-l-4 border-amber-500">
                <p className="text-sm font-medium text-secondary-900">
                  <span className="text-amber-600 font-bold">Ziel:</span> Stoffwechsel regulieren, Energie verbessern, Körper entlasten.
                </p>
              </div>
            </div>

            {/* Service 4 */}
            <div className="p-8 rounded-2xl bg-secondary-50 border border-secondary-100 hover:shadow-xl transition-shadow group">
              <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Heart size={28} />
              </div>
              <h3 className="text-xl font-heading font-bold text-secondary-900 mb-4">Gewohnheiten & Lebensweise</h3>
              <ul className="text-secondary-700 mb-4 space-y-1 text-sm list-disc pl-4">
                <li>Raucherentwöhnung</li>
                <li>Konzentrationsschwäche</li>
                <li>Individuelle Gesundheitsberatung</li>
              </ul>
              <div className="bg-white p-4 rounded-lg border-l-4 border-rose-500">
                <p className="text-sm font-medium text-secondary-900">
                  <span className="text-rose-600 font-bold">Ziel:</span> Ungesunde Muster lösen, bessere Lebensqualität erreichen.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. ABLAUF SECTION */}
      <section id="ablauf" className="py-20 bg-secondary-900 text-secondary-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">
              Ablauf einer Sitzung
            </h2>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-secondary-800 rounded-full text-primary-300 border border-secondary-700">
              <Clock size={16} />
              <span>Dauer: ca. 45–60 Minuten</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: "Erstgespräch", desc: "Ausführliche Anamnese Ihrer Situation." },
              { title: "Frequenzanalyse", desc: "Messung der energetischen Belastungen." },
              { title: "Ausgleich", desc: "Individuell abgestimmte Bioresonanz." },
              { title: "Empfehlung", desc: "Beratung für Ihre weiteren Schritte." }
            ].map((step, idx) => (
              <div key={idx} className="relative p-6 bg-secondary-800 rounded-xl border border-secondary-700 hover:border-primary-500 transition-colors">
                <div className="absolute -top-4 -left-4 w-10 h-10 bg-primary-600 rounded-full flex items-center justify-center font-bold text-white shadow-lg">
                  {idx + 1}
                </div>
                <h3 className="text-xl font-bold text-white mt-2 mb-2">{step.title}</h3>
                <p className="text-secondary-300">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. KONTAKT SECTION */}
      <section id="kontakt" className="py-20 bg-secondary-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden border border-secondary-100">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8 md:p-12 space-y-8">
                <div>
                  <h2 className="text-3xl font-heading font-bold text-secondary-900 mb-2">Kontakt & Termin</h2>
                  <p className="text-secondary-600">Ich freue mich darauf, Sie in meiner Praxis begrüßen zu dürfen.</p>
                </div>

                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-primary-50 text-primary-600 rounded-lg">
                      <MapPin size={24} />
                    </div>
                    <div>
                      <p className="font-bold text-secondary-900">Adresse</p>
                      <p className="text-secondary-600">Eduard-Sueß-Gasse 17/16<br/>1150 Wien</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-primary-50 text-primary-600 rounded-lg">
                      <Phone size={24} />
                    </div>
                    <div>
                      <p className="font-bold text-secondary-900">Telefon</p>
                      <a href="tel:+436601540305" className="text-secondary-600 hover:text-primary-600 transition-colors">+43 660 1540305</a>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-primary-50 text-primary-600 rounded-lg">
                      <Mail size={24} />
                    </div>
                    <div>
                      <p className="font-bold text-secondary-900">E-Mail</p>
                      <a href="mailto:info@biorezonanz-toker-wien.at" className="text-secondary-600 hover:text-primary-600 transition-colors break-all">info@biorezonanz-toker-wien.at</a>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-primary-50 text-primary-600 rounded-lg">
                      <Calendar size={24} />
                    </div>
                    <div>
                      <p className="font-bold text-secondary-900">Öffnungszeiten</p>
                      <p className="text-secondary-600">Nach Vereinbarung</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-primary-900 p-8 md:p-12 flex flex-col justify-center text-white relative overflow-hidden">
                <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
                <h3 className="text-2xl font-bold mb-6 relative z-10">Bereit für mehr Wohlbefinden?</h3>
                <p className="text-primary-100 mb-8 relative z-10">
                  Vereinbaren Sie jetzt Ihren persönlichen Termin für eine Bioresonanz-Analyse.
                </p>
                
                {/* Button wurde hier entfernt */}
                
                <p className="text-xs text-primary-300 mt-4 text-center relative z-10">
                  Inhaber: Hasan Toker, B.A.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};